Fractal Tunnel Runner - Windows Edition
========================================

REQUIREMENTS:
- Windows 10/11
- Java 21 or higher (download from https://adoptium.net/)

INSTALLATION:
1. Ensure Java 21+ is installed (run "java -version" in cmd)
2. Double-click FractalTunnel.bat to launch

CONTROLS:
W/S     - Boost forward / Brake
A/D     - Strafe left/right  
R/F     - Move up/down
Arrows  - Pitch/Yaw (look around)
Q/E     - Roll (bank turns)
SPACE   - Recenter to tunnel axis
R (game over) - Restart

TIPS:
- Stay centered to build combo multiplier
- Collect green health, blue shields, yellow slow-time
- Checkpoints every 100m restore 20 HP
- Survive as long as possible!

Created with Scala 3 + ray marching
Visit: https://github.com/yourusername/ScalaDescent
